# -*- coding: utf-8 -*-


from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('commerce', '0002_commerceconfiguration'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='commerceconfiguration',
            options={},
        ),
    ]
