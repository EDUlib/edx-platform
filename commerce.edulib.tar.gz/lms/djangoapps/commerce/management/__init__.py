"""
Management commands related to commerce configuration.
"""
